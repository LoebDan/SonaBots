import tweepy
from time import sleep
from credentials import *
import random

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth)

# Files containing top trending words during SONA
files = ['SONA160211', 'SONA170217', 'SONA180216', 'SONA180221', 'SONA180222']

# Randomly choose which file will be chosen
def hashtag():
    chosen = 'cleaner/' + random.choice(files) + ".txt"
    f = open(chosen, 'r')
    posshas = f.readlines()
    hash = random.choice(posshas)
    print(hash)
    return hash

hashtag()


def builder():
    f = open('afrgib.txt', 'r')
    words = f.readlines()
    sentence = ""
    wordnum = random.randint(8, 22)
    print(wordnum)
    for x in range(wordnum):
        word = random.choice(words)
        sentence = word + " " + sentence

    # mod the random number that determined how many words would be used, then add one. The answer equals how many hashtags I will use.
    hashnum = (wordnum%3) + 1
    print(hashnum)
    for x in range(hashnum):
        sentence = sentence + hashtag() + " "
    sentence = sentence.replace("\n", "")
    print(sentence)
    print(len(sentence))
    if(len(sentence) > 280):
        builder()
    else:
        return sentence
builder()

def tweet():
    try:
        sen = builder()
        print(sen)
        api.update_status(sen)
    except tweepy.TweepError as e:
        print(e.reason)
        sleep(2)

for x in range(100):
    timer = random.randint(300, 3600)
    tweet()
    sleep(timer)
